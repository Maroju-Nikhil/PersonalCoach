import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Detect emotion/sentiment from AI response
function detectEmotion(text: string): string {
  const lowerText = text.toLowerCase();
  
  if (lowerText.match(/\b(excited|amazing|wonderful|fantastic|love|great)\b/)) {
    return 'excited';
  }
  if (lowerText.match(/\b(sad|sorry|unfortunately|difficult|hard)\b/)) {
    return 'sad';
  }
  if (lowerText.match(/\b(thinking|consider|perhaps|maybe|analyzing)\b/)) {
    return 'thinking';
  }
  if (lowerText.match(/\b(calm|peaceful|relax|gentle|soothing)\b/)) {
    return 'calm';
  }
  if (lowerText.match(/\b(happy|glad|pleased|delighted|joy)\b/)) {
    return 'happy';
  }
  
  return 'neutral';
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    console.log('Received chat request with messages:', messages);

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { 
            role: 'system', 
            content: 'You are a vibrant, emotionally expressive AI assistant. Show personality and emotion in your responses. Use words like "excited", "happy", "thinking", "calm", or "amazing" to express feelings naturally.' 
          },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        console.error('Rate limit exceeded');
        return new Response(JSON.stringify({ error: 'Rate limit exceeded. Please try again in a moment.' }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      if (response.status === 402) {
        console.error('Payment required');
        return new Response(JSON.stringify({ error: 'AI credits depleted. Please add credits to continue.' }), {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      return new Response(JSON.stringify({ error: 'AI gateway error' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Create a TransformStream to intercept and analyze the response
    const { readable, writable } = new TransformStream();
    const writer = writable.getWriter();
    const reader = response.body!.getReader();
    const decoder = new TextDecoder();
    
    let accumulatedText = '';

    (async () => {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (!line.trim() || line.startsWith(':')) continue;
            if (!line.startsWith('data: ')) continue;

            const jsonStr = line.slice(6).trim();
            if (jsonStr === '[DONE]') continue;

            try {
              const parsed = JSON.parse(jsonStr);
              const content = parsed.choices?.[0]?.delta?.content as string | undefined;
              
              if (content) {
                accumulatedText += content;
                
                // Detect emotion every few words
                if (accumulatedText.split(' ').length % 10 === 0) {
                  const emotion = detectEmotion(accumulatedText);
                  // Send custom emotion event
                  const emotionEvent = `data: ${JSON.stringify({ 
                    type: 'emotion', 
                    emotion,
                    timestamp: Date.now() 
                  })}\n\n`;
                  await writer.write(new TextEncoder().encode(emotionEvent));
                }
              }
            } catch (e) {
              // Ignore parse errors for partial chunks
            }
          }

          // Forward the original chunk
          await writer.write(value);
        }

        // Send final emotion
        const finalEmotion = detectEmotion(accumulatedText);
        const finalEmotionEvent = `data: ${JSON.stringify({ 
          type: 'emotion', 
          emotion: finalEmotion,
          final: true,
          timestamp: Date.now() 
        })}\n\n`;
        await writer.write(new TextEncoder().encode(finalEmotionEvent));
        
        await writer.close();
      } catch (error) {
        console.error('Stream processing error:', error);
        await writer.abort(error);
      }
    })();

    return new Response(readable, {
      headers: { ...corsHeaders, 'Content-Type': 'text/event-stream' },
    });

  } catch (error) {
    console.error('Chat error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});