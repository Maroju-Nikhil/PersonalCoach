import { useState } from 'react';
import BackgroundEffects from '@/components/BackgroundEffects';
import ChatMessage from '@/components/ChatMessage';
import ChatInput from '@/components/ChatInput';
import { useAIChat } from '@/hooks/useAIChat';
import { Sparkles } from 'lucide-react';

const Index = () => {
  const { messages, sendMessage, isLoading, currentEmotion } = useAIChat();
  const [showChat, setShowChat] = useState(false);

  return (
    <div className="relative min-h-screen overflow-hidden">
      <BackgroundEffects emotion={currentEmotion} />
      
      <div className="relative z-10 flex flex-col min-h-screen">
        {!showChat ? (
          // Hero Section
          <div className="flex-1 flex flex-col items-center justify-center px-4 py-12">
            <div className="text-center max-w-4xl mx-auto">
              <div className="mb-8 animate-float">
                <Sparkles className="w-20 h-20 mx-auto text-primary" />
              </div>
              
              <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary via-secondary to-accent animate-gradient-shift bg-[length:200%_auto]">
                Experience AI
              </h1>
              
              <p className="text-xl md:text-2xl mb-12 text-muted-foreground">
                Where conversations come alive with emotion and personality
              </p>
              
              <button
                onClick={() => setShowChat(true)}
                className="px-12 py-6 text-xl font-semibold rounded-3xl bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_40px_hsl(260_85%_65%/0.6)] hover:shadow-[0_0_60px_hsl(260_85%_65%/0.8)] transition-all duration-300 hover:scale-105"
              >
                Start Chatting
              </button>
            </div>
          </div>
        ) : (
          // Chat Interface
          <div className="flex-1 flex flex-col max-w-4xl w-full mx-auto px-4 py-8">
            <div className="mb-6 text-center">
              <h2 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
                AI Chat
              </h2>
              <p className="text-sm text-muted-foreground mt-2">
                Watch the interface respond to the conversation's mood
              </p>
            </div>
            
            <div className="flex-1 overflow-y-auto mb-6 space-y-4 backdrop-blur-sm rounded-3xl p-6 bg-card/20 border border-primary/20">
              {messages.length === 0 && (
                <div className="text-center text-muted-foreground py-12">
                  <p className="text-lg">Start a conversation and watch the magic happen...</p>
                </div>
              )}
              
              {messages.map((msg, idx) => (
                <ChatMessage
                  key={idx}
                  role={msg.role}
                  content={msg.content}
                  emotion={msg.emotion}
                />
              ))}
              
              {isLoading && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                  <div className="w-2 h-2 bg-secondary rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                  <div className="w-2 h-2 bg-accent rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                </div>
              )}
            </div>
            
            <ChatInput onSend={sendMessage} disabled={isLoading} />
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;