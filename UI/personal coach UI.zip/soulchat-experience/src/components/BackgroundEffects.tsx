import { useEffect, useState } from 'react';

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  opacity: number;
}

interface BackgroundEffectsProps {
  emotion?: string;
}

const BackgroundEffects = ({ emotion = 'neutral' }: BackgroundEffectsProps) => {
  const [particles, setParticles] = useState<Particle[]>([]);
  
  useEffect(() => {
    // Generate initial particles
    const initialParticles: Particle[] = Array.from({ length: 30 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 2,
      speedX: (Math.random() - 0.5) * 0.5,
      speedY: (Math.random() - 0.5) * 0.5,
      opacity: Math.random() * 0.5 + 0.3,
    }));
    setParticles(initialParticles);

    // Animate particles
    const interval = setInterval(() => {
      setParticles(prev => prev.map(p => ({
        ...p,
        x: (p.x + p.speedX + 100) % 100,
        y: (p.y + p.speedY + 100) % 100,
      })));
    }, 50);

    return () => clearInterval(interval);
  }, []);

  // Get color based on emotion
  const getEmotionColor = () => {
    switch (emotion) {
      case 'happy':
        return 'hsl(45 95% 60% / 0.6)';
      case 'excited':
        return 'hsl(15 90% 60% / 0.6)';
      case 'sad':
        return 'hsl(220 40% 50% / 0.6)';
      case 'calm':
        return 'hsl(160 50% 55% / 0.6)';
      case 'thinking':
        return 'hsl(280 70% 60% / 0.6)';
      default:
        return 'hsl(260 85% 65% / 0.6)';
    }
  };

  return (
    <>
      {/* Ambient gradient background */}
      <div className="fixed inset-0 pointer-events-none">
        <div 
          className="absolute inset-0 opacity-30 transition-all duration-1000"
          style={{
            background: `radial-gradient(circle at 50% 50%, ${getEmotionColor()}, transparent 70%)`,
          }}
        />
      </div>

      {/* Floating particles */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {particles.map(particle => (
          <div
            key={particle.id}
            className="absolute rounded-full transition-all duration-1000"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
              backgroundColor: getEmotionColor(),
              opacity: particle.opacity,
              boxShadow: `0 0 ${particle.size * 2}px ${getEmotionColor()}`,
            }}
          />
        ))}
      </div>

      {/* Animated gradient overlay */}
      <div 
        className="fixed inset-0 pointer-events-none opacity-20 transition-opacity duration-1000"
        style={{
          background: 'linear-gradient(135deg, hsl(260 85% 65% / 0.2), hsl(280 90% 70% / 0.2), hsl(300 85% 65% / 0.2))',
          backgroundSize: '200% 200%',
          animation: 'gradient-shift 8s ease infinite',
        }}
      />
    </>
  );
};

export default BackgroundEffects;