import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Send } from 'lucide-react';

interface ChatInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
}

const ChatInput = ({ onSend, disabled }: ChatInputProps) => {
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (input.trim() && !disabled) {
      onSend(input.trim());
      setInput('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex gap-2 items-end">
      <Textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Share your thoughts..."
        disabled={disabled}
        className="min-h-[60px] resize-none bg-card/40 backdrop-blur-md border-2 border-primary/50 focus:border-primary rounded-2xl text-foreground placeholder:text-muted-foreground"
      />
      <Button
        onClick={handleSend}
        disabled={disabled || !input.trim()}
        className="h-[60px] w-[60px] rounded-2xl bg-primary hover:bg-primary/90 shadow-[0_0_20px_hsl(260_85%_65%/0.4)] hover:shadow-[0_0_30px_hsl(260_85%_65%/0.6)] transition-all"
      >
        <Send className="h-5 w-5" />
      </Button>
    </div>
  );
};

export default ChatInput;