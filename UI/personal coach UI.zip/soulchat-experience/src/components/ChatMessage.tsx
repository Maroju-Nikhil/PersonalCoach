import { useEffect, useState } from 'react';

interface ChatMessageProps {
  role: 'user' | 'assistant';
  content: string;
  emotion?: string;
}

const ChatMessage = ({ role, content, emotion = 'neutral' }: ChatMessageProps) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
  }, []);

  const getEmotionStyles = () => {
    switch (emotion) {
      case 'happy':
        return 'border-[hsl(45_95%_60%)] shadow-[0_0_20px_hsl(45_95%_60%/0.3)]';
      case 'excited':
        return 'border-[hsl(15_90%_60%)] shadow-[0_0_20px_hsl(15_90%_60%/0.3)]';
      case 'sad':
        return 'border-[hsl(220_40%_50%)] shadow-[0_0_20px_hsl(220_40%_50%/0.3)]';
      case 'calm':
        return 'border-[hsl(160_50%_55%)] shadow-[0_0_20px_hsl(160_50%_55%/0.3)]';
      case 'thinking':
        return 'border-[hsl(280_70%_60%)] shadow-[0_0_20px_hsl(280_70%_60%/0.3)]';
      default:
        return 'border-primary shadow-[0_0_20px_hsl(260_85%_65%/0.3)]';
    }
  };

  return (
    <div
      className={`
        ${visible ? 'animate-message-appear' : 'opacity-0'}
        ${role === 'user' ? 'ml-auto' : 'mr-auto'}
        max-w-[80%] mb-4 p-4 rounded-2xl backdrop-blur-md
        border-2 transition-all duration-500
        ${role === 'user' 
          ? 'bg-primary/20 border-primary text-foreground' 
          : `bg-card/40 ${getEmotionStyles()} text-foreground`
        }
      `}
    >
      <p className="whitespace-pre-wrap">{content}</p>
    </div>
  );
};

export default ChatMessage;